<?php
// modules/bpm/bpm_designer.php
// Mozart BPM — Modeler com Properties + Element Templates (CDN + fallback local)

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../config.php';
require_once ROOT_PATH . '/system/config/autenticacao.php';
require_once ROOT_PATH . '/system/config/connect.php';

// Abre <html><head>...<body>
include_once ROOT_PATH . 'system/includes/head.php';
?>

<link href="<?= BASE_URL ?>/modules/gestao_ativos/includes/css/style_gestao_ativos.css?v=1.0.0" rel="stylesheet">

<?php
// (se o seu navbar ficar dentro do head/footer, não precisa incluir aqui)
include_once ROOT_PATH . 'system/includes/navbar.php';
?>

<!-- Page Content -->
<div id="page-wrapper">
  <div class="container-fluid">
    <div class="row"><div class="col-lg-12"><h1 class="page-header"><?= APP_NAME ?></h1></div></div>

    <div class="row">
      <div class="col-lg-12">
<!-- Top Content -->


<session class="bpm">
  <div class="container">
    
<header class="toolbar">
  <h1>Modelos — Cadastro</h1>
  <div class="actions">
    <a class="btn" href="modelos-listar.html">Listar modelos</a>
  </div>
</header>

<form class="card" autocomplete="off" novalidate>
  <p class="subtitle">Identificação</p>
  <div class="grid cols-3">
    <div>
      <label>Categoria *</label>
      <select>
        <option>Notebook</option>
        <option>Impressora térmica</option>
        <option>Balança</option>
      </select>
    </div>
    <div>
      <label>Fabricante *</label>
      <select>
        <option>Dell</option><option>HP</option><option>Toledo</option>
      </select>
    </div>
    <div>
      <label>Nome do modelo *</label>
      <input type="text" placeholder="Ex.: Latitude 5440 / ZT-230 / Prix 5"/>
    </div>
  </div>

  <div class="grid cols-3">
    <div>
      <label>Código interno</label>
      <input type="text" placeholder="SKU interno / referência"/>
    </div>
    <div>
      <label>Status *</label>
      <select><option>Ativo</option><option>Inativo</option></select>
    </div>
    <div>
      <label>Vida útil sugerida (meses)</label>
      <input type="number" min="0" placeholder="36"/>
    </div>
  </div>

  <div class="grid cols-2">
    <div class="stack">
      <label>Imagem principal</label>
      <div class="file-zone">Arraste aqui ou <button type="button" class="btn small">escolha</button><input type="file" accept="image/*"/></div>
      <span class="hint">PNG/JPG/SVG • fundo transparente recomendado</span>
    </div>
    <div>
      <label>Descrição</label>
      <textarea placeholder="Resumo do modelo, indicação de uso, observações."></textarea>
    </div>
  </div>

  <div class="divider"></div>

  <p class="subtitle">Especificações do modelo</p>
  <div id="spec-list" class="stack"></div>
  <button type="button" class="btn small" id="add-spec">+ Adicionar especificação</button>

  <div class="divider"></div>

  <p class="subtitle">Compatibilidades (peças/acessórios)</p>
  <div id="compat-list" class="stack"></div>
  <button type="button" class="btn small" id="add-compat">+ Adicionar compatibilidade</button>

  <div class="divider"></div>

  <div style="display:flex;justify-content:flex-end;gap:10px">
    <button class="btn" type="button">Cancelar</button>
    <button class="btn primary" type="button">Salvar (visual)</button>
  </div>
</form>

<div class="card"><p class="hint">Mock visual. Depois mapeamos tabelas e ações.</p></div>

</session>

  <!-- Fim Content -->
        </div>
    </div>
  </div>
</div>

<?php
include_once ROOT_PATH . 'system/includes/code_footer.php';
?>
  
<script>
function specRow(){
  const el=document.createElement('div'); el.className='grid cols-3'; el.style.alignItems='end';
  el.innerHTML=`
    <div><label>Nome *</label><input type="text" placeholder="Ex.: CPU, RAM, Armazenamento"/></div>
    <div><label>Valor *</label><input type="text" placeholder="Ex.: i5 / 16 GB / 512 GB SSD"/></div>
    <div class="row"><button type="button" class="btn small danger">Remover</button></div>`;
  el.querySelector('.btn.danger').addEventListener('click',()=>el.remove()); return el;
}
function compatRow(){
  const el=document.createElement('div'); el.className='grid cols-4'; el.style.alignItems='end';
  el.innerHTML=`
    <div><label>Tipo</label><select><option>Peça</option><option>Acessório</option><option>Consumível</option></select></div>
    <div><label>Referência</label><input type="text" placeholder="Categoria/Modelo"/></div>
    <div><label>Observação</label><input type="text" placeholder="Ex.: compatível até rev. B"/></div>
    <div class="row"><button type="button" class="btn small danger">Remover</button></div>`;
  el.querySelector('.btn.danger').addEventListener('click',()=>el.remove()); return el;
}
const specList=document.getElementById('spec-list');
const compatList=document.getElementById('compat-list');
document.getElementById('add-spec').addEventListener('click',()=>specList.appendChild(specRow()));
document.getElementById('add-compat').addEventListener('click',()=>compatList.appendChild(compatRow()));
specList.appendChild(specRow()); specList.appendChild(specRow());
</script>



<?php
include_once ROOT_PATH . 'system/includes/footer.php';
?>