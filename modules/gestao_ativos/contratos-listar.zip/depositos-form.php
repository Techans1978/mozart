<?php
// modules/bpm/bpm_designer.php
// Mozart BPM — Modeler com Properties + Element Templates (CDN + fallback local)

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../config.php';
require_once ROOT_PATH . '/system/config/autenticacao.php';
require_once ROOT_PATH . '/system/config/connect.php';

// Abre <html><head>...<body>
include_once ROOT_PATH . 'system/includes/head.php';
?>

<link href="<?= BASE_URL ?>/modules/gestao_ativos/includes/css/style_gestao_ativos.css?v=1.0.0" rel="stylesheet">

<?php
// (se o seu navbar ficar dentro do head/footer, não precisa incluir aqui)
include_once ROOT_PATH . 'system/includes/navbar.php';
?>

<!-- Page Content -->
<div id="page-wrapper">
  <div class="container-fluid">
    <div class="row"><div class="col-lg-12"><h1 class="page-header"><?= APP_NAME ?></h1></div></div>

    <div class="row">
      <div class="col-lg-12">
<!-- Top Content -->


<session class="bpm">
  <div class="container">
    
<header class="toolbar">
  <h1>Depósitos — Cadastro</h1>
  <div class="actions">
    <a class="btn" href="depositos-listar.html">Listar depósitos</a>
  </div>
</header>

<form class="card" autocomplete="off" novalidate>
  <p class="subtitle">Identificação</p>
  <div class="grid cols-3">
    <div><label>Empresa/Entidade *</label><select><option>Matriz</option><option>Filial 01</option></select></div>
    <div><label>Nome do depósito *</label><input type="text" placeholder="Depósito Central"/></div>
    <div><label>Status *</label><select><option>Ativo</option><option>Inativo</option></select></div>
  </div>

  <div class="grid cols-3">
    <div><label>Código interno</label><input type="text" placeholder="SIGLA/ID"/></div>
    <div><label>Tipo</label><select><option>Geral</option><option>Peças</option><option>Consumíveis</option><option>Ativos de TI</option></select></div>
    <div><label>Responsável</label><input type="text" placeholder="Nome/usuário"/></div>
  </div>

  <div class="divider"></div>
  <p class="subtitle">Endereço & contato</p>
  <div class="grid cols-4">
    <div><label>CEP</label><input type="text" placeholder="00000-000"/></div>
    <div class="cols-span-3"><label>Logradouro</label><input type="text" placeholder="Rua/Avenida"/></div>
  </div>
  <div class="grid cols-4">
    <div><label>Número</label><input type="text" placeholder="S/N"/></div>
    <div><label>Complemento</label><input type="text" placeholder="Galpão, doca..."/></div>
    <div><label>Bairro</label><input type="text"/></div>
    <div><label>Município</label><input type="text"/></div>
  </div>
  <div class="grid cols-3">
    <div><label>UF</label><input type="text" placeholder="SP, RJ..."/></div>
    <div><label>Telefone</label><input type="tel" placeholder="(11) 4000-0000"/></div>
    <div><label>E-mail</label><input type="email" placeholder="estoque@empresa.com.br"/></div>
  </div>

  <div class="divider"></div>
  <p class="subtitle">Operação</p>
  <div class="grid cols-3">
    <div><label>Horário de funcionamento</label><input type="text" placeholder="Seg–Sex 08:00–17:00"/></div>
    <div><label>Política de picking</label><select><option>FIFO</option><option>FEFO</option><option>LIFO</option></select></div>
    <div><label>Capacidade (m³) / posições</label><input type="text" placeholder="Ex.: 120 / 300 posições"/></div>
  </div>

  <div class="grid cols-3">
    <div><label>Categorias permitidas</label><input type="text" placeholder="Ex.: Consumíveis; Peças"/></div>
    <div><label>Estoque mínimo (alerta)</label><input type="number" min="0"/></div>
    <div><label>Estoque máximo</label><input type="number" min="0"/></div>
  </div>

  <div class="divider"></div>
  <p class="subtitle">Zonas e endereçamento (opcional)</p>
  <div id="zonas" class="stack"></div>
  <button type="button" class="btn small" id="add-zona">+ Adicionar zona/rua</button>

  <div class="divider"></div>
  <p class="subtitle">Observações</p>
  <textarea placeholder="Regras de segurança, EPIs, docas, acesso etc."></textarea>

  <div class="divider"></div>
  <div style="display:flex;justify-content:flex-end;gap:10px">
    <button class="btn" type="button">Cancelar</button>
    <button class="btn primary" type="button">Salvar (visual)</button>
  </div>
</form>

<div class="card"><p class="hint">Mock visual. Depois mapeamos hierarquia de endereços (zona/rua/coluna/nível) e integração com estoque.</p></div>

</session>

  <!-- Fim Content -->
        </div>
    </div>
  </div>
</div>

<?php
include_once ROOT_PATH . 'system/includes/code_footer.php';
?>
  
<script>
function zonaRow(){
  const el=document.createElement('div'); el.className='grid cols-4'; el.style.alignItems='end';
  el.innerHTML=`
    <div><label>Zona/Área</label><input type="text" placeholder="Ex.: Zona A"/></div>
    <div><label>Rua/Corredor</label><input type="text" placeholder="Ex.: Rua 01"/></div>
    <div><label>Colunas x Níveis</label><input type="text" placeholder="Ex.: 10 x 4"/></div>
    <div class="row"><button type="button" class="btn small danger">Remover</button></div>
  `;
  el.querySelector('.btn.danger').addEventListener('click',()=>el.remove()); return el;
}
const zonas=document.getElementById('zonas');
document.getElementById('add-zona').addEventListener('click',()=>zonas.appendChild(zonaRow()));
zonas.appendChild(zonaRow());
</script>



<?php
include_once ROOT_PATH . 'system/includes/footer.php';
?>