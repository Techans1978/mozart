<?php
// modules/bpm/bpm_designer.php
// Mozart BPM — Modeler com Properties + Element Templates (CDN + fallback local)

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../config.php';
require_once ROOT_PATH . '/system/config/autenticacao.php';
require_once ROOT_PATH . '/system/config/connect.php';

// Abre <html><head>...<body>
include_once ROOT_PATH . 'system/includes/head.php';
?>

<link href="<?= BASE_URL ?>/modules/gestao_ativos/includes/css/style_gestao_ativos.css?v=1.0.0" rel="stylesheet">

<?php
// (se o seu navbar ficar dentro do head/footer, não precisa incluir aqui)
include_once ROOT_PATH . 'system/includes/navbar.php';
?>

<!-- Page Content -->
<div id="page-wrapper">
  <div class="container-fluid">
    <div class="row"><div class="col-lg-12"><h1 class="page-header"><?= APP_NAME ?></h1></div></div>

    <div class="row">
      <div class="col-lg-12">
<!-- Top Content -->


<session class="bpm">

  <div class="container">
    
<header class="toolbar">
  <h1>Técnicos & Filas — Cadastro</h1>
  <div class="actions"><a class="btn" href="tecnicos-filas-listar.html">Listar</a></div>
</header>

<form class="card" onsubmit="return false">
  <p class="subtitle">Tipo de cadastro</p>
  <div class="toggle">
    <input type="radio" id="r-tec" name="tipo" checked><label for="r-tec">Técnico</label>
    <input type="radio" id="r-fila" name="tipo"><label for="r-fila">Fila</label>
  </div>
</form>

<form class="card" id="tec" onsubmit="return false">
  <p class="subtitle">Dados do Técnico</p>
  <div class="grid cols-3">
    <div><label>Nome</label><input type="text"/></div>
    <div><label>E-mail</label><input type="email"/></div>
    <div><label>Telefone</label><input type="tel"/></div>
  </div>
  <div class="grid cols-3">
    <div><label>Time</label><input type="text"/></div>
    <div><label>Entidades atendidas</label><input type="text" placeholder="Matriz, Filial 01"/></div>
    <div><label>Turno</label><select><option>8x5</option><option>24x7</option></select></div>
  </div>
  <div class="divider"></div>
  <p class="subtitle">Habilidades</p>
  <div id="skills" class="stack"></div>
  <button type="button" class="btn small" id="add-skill">+ Adicionar skill</button>
  <div class="divider"></div>
  <div class="row" style="justify-content:flex-end;gap:10px">
    <button class="btn">Salvar</button><button class="btn primary">Publicar</button>
  </div>
</form>

<form class="card" id="fila" style="display:none" onsubmit="return false">
  <p class="subtitle">Dados da Fila</p>
  <div class="grid cols-3">
    <div><label>Nome da fila</label><input type="text"/></div>
    <div><label>Escopo</label><select><option>Global</option><option>Entidade</option><option>Local</option></select></div>
    <div><label>Horário</label><select><option>8x5</option><option>24x7</option></select></div>
  </div>
  <div class="grid cols-3">
    <div><label>Serviços / Categorias</label><input type="text" placeholder="Notebook, Telefone, Impressora"/></div>
    <div><label>Roteamento</label><select><option>Round-robin</option><option>Por skill</option><option>Por carga</option><option>Por prioridade</option></select></div>
    <div><label>Limite simultâneo</label><input type="number" min="1" value="10"/></div>
  </div>
  <div class="divider"></div>
  <p class="subtitle">Técnicos da fila</p>
  <div id="tf-tecs" class="stack"></div>
  <button type="button" class="btn small" id="add-tf-tec">+ Adicionar técnico</button>
  <div class="divider"></div>
  <div class="row" style="justify-content:flex-end;gap:10px">
    <button class="btn">Salvar</button><button class="btn primary">Publicar</button>
  </div>
</form>
</session>

  <!-- Fim Content -->
        </div>
    </div>
  </div>
</div>

<?php
include_once ROOT_PATH . 'system/includes/code_footer.php';
?>

<script>
const rTec=document.getElementById('r-tec'); const rFila=document.getElementById('r-fila');
const formTec=document.getElementById('tec'); const formFila=document.getElementById('fila');
function toggle(){ const isTec=rTec.checked; formTec.style.display=isTec?'':'none'; formFila.style.display=isTec?'none':''; }
rTec.addEventListener('change',toggle); rFila.addEventListener('change',toggle); toggle();
function skillRow(){
  const el=document.createElement('div'); el.className='grid cols-4'; el.style.alignItems='end';
  el.innerHTML=`
    <div><label>Categoria/Serviço</label><input type="text" placeholder="Impressoras / Zebra"/></div>
    <div><label>Nível</label><select><option>1</option><option>2</option><option selected>3</option><option>4</option><option>5</option></select></div>
    <div><label>Observ.</label><input type="text" placeholder="Certificação, experiência"/></div>
    <div class="row"><button type="button" class="btn small danger">Remover</button></div>`;
  el.querySelector('.btn.danger').addEventListener('click',()=>el.remove()); return el;
}
document.getElementById('add-skill').addEventListener('click',()=>document.getElementById('skills').appendChild(skillRow()));
document.getElementById('skills').appendChild(skillRow());
function filaTecRow(){
  const el=document.createElement('div'); el.className='grid cols-3'; el.style.alignItems='end';
  el.innerHTML=`
    <div><label>Técnico</label><input type="text" placeholder="Nome"/></div>
    <div><label>Prioridade</label><select><option>Normal</option><option>Alta</option></select></div>
    <div class="row"><button type="button" class="btn small danger">Remover</button></div>`;
  el.querySelector('.btn.danger').addEventListener('click',()=>el.remove()); return el;
}
document.getElementById('add-tf-tec').addEventListener('click',()=>document.getElementById('tf-tecs').appendChild(filaTecRow()));
document.getElementById('tf-tecs').appendChild(filaTecRow());
</script>








<?php
include_once ROOT_PATH . 'system/includes/footer.php';
?>