<?php
// modules/bpm/bpm_designer.php
// Mozart BPM — Modeler com Properties + Element Templates (CDN + fallback local)

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../config.php';
require_once ROOT_PATH . '/system/config/autenticacao.php';
require_once ROOT_PATH . '/system/config/connect.php';

// Abre <html><head>...<body>
include_once ROOT_PATH . 'system/includes/head.php';
?>

<link href="<?= BASE_URL ?>/modules/gestao_ativos/includes/css/style_gestao_ativos.css?v=1.0.0" rel="stylesheet">

<?php
// (se o seu navbar ficar dentro do head/footer, não precisa incluir aqui)
include_once ROOT_PATH . 'system/includes/navbar.php';
?>

<!-- Page Content -->
<div id="page-wrapper">
  <div class="container-fluid">
    <div class="row"><div class="col-lg-12"><h1 class="page-header"><?= APP_NAME ?></h1></div></div>

    <div class="row">
      <div class="col-lg-12">
<!-- Top Content -->


<session class="bpm">

  <div class="container">
    
<header class="toolbar">
  <h1>Etiquetas / QR — Listar</h1>
  <div class="actions"><a class="btn" href="etiquetas-qr-form.html">Nova emissão</a><button class="btn">Exportar CSV</button></div>
</header>

<form class="card" onsubmit="return false;">
  <p class="subtitle">Filtros</p>
  <div class="grid cols-4">
    <div><label>Busca</label><input type="text" placeholder="tag, serial, modelo"/></div>
    <div><label>Entidade</label><select><option>—</option><option>Matriz</option><option>Filial 01</option></select></div>
    <div><label>Categoria</label><select><option>—</option><option>Notebook</option><option>Impressora</option></select></div>
    <div><label>Situação</label><select><option>—</option><option>Em uso</option><option>Estoque</option><option>Emprestado</option><option>Baixado</option></select></div>
  </div>
</form>
<section id="list" class="grid cols-2">

<article class="card">
  <div class="row" style="justify-content:space-between;align-items:flex-start">
    <div>
      <div style="font-weight:700">NB-0001</div>
      <div class="hint">Latitude 5440 • Dell</div>
    </div>
    <div class="row" style="gap:6px;flex-wrap:wrap"><span class="pill">Em uso</span> <span class="pill">Impressões: 3</span></div>
  </div>
  <div class="divider"></div>
  <div class="grid cols-3"><div><label>Local</label><div>TI • Matriz</div></div><div><label>Usuário</label><div>Ana</div></div><div><label>Criada</label><div>10/01/2025</div></div></div>
  <div class="divider"></div>
  <div class="row" style="justify-content:flex-end;gap:8px"><a class="btn small" href="etiquetas-qr-form.html">Editar</a><a class="btn small" href="#">Inativar</a><a class="btn small" href="#">Excluir</a><a class="btn small" href="etiquetas-qr-form.html">Imprimir</a></div>
</article>

<article class="card">
  <div class="row" style="justify-content:space-between;align-items:flex-start">
    <div>
      <div style="font-weight:700">IMP-010</div>
      <div class="hint">ZT-230 • Zebra</div>
    </div>
    <div class="row" style="gap:6px;flex-wrap:wrap"><span class="pill">Estoque</span> <span class="pill">Impressões: 1</span></div>
  </div>
  <div class="divider"></div>
  <div class="grid cols-3"><div><label>Local</label><div>Depósito Central</div></div><div><label>Usuário</label><div>—</div></div><div><label>Criada</label><div>05/01/2025</div></div></div>
  <div class="divider"></div>
  <div class="row" style="justify-content:flex-end;gap:8px"><a class="btn small" href="etiquetas-qr-form.html">Editar</a><a class="btn small" href="#">Inativar</a><a class="btn small" href="#">Excluir</a><a class="btn small" href="etiquetas-qr-form.html">Imprimir</a></div>
</article>

</section>

</session>

  <!-- Fim Content -->
        </div>
    </div>
  </div>
</div>

<?php
include_once ROOT_PATH . 'system/includes/code_footer.php';
?>






<?php
include_once ROOT_PATH . 'system/includes/footer.php';
?>