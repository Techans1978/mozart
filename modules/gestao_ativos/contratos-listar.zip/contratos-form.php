<?php
// modules/bpm/bpm_designer.php
// Mozart BPM — Modeler com Properties + Element Templates (CDN + fallback local)

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../config.php';
require_once ROOT_PATH . '/system/config/autenticacao.php';
require_once ROOT_PATH . '/system/config/connect.php';

// Abre <html><head>...<body>
include_once ROOT_PATH . 'system/includes/head.php';
?>

<link href="<?= BASE_URL ?>/modules/gestao_ativos/includes/css/style_gestao_ativos.css?v=1.0.0" rel="stylesheet">

<?php
// (se o seu navbar ficar dentro do head/footer, não precisa incluir aqui)
include_once ROOT_PATH . 'system/includes/navbar.php';
?>

<!-- Page Content -->
<div id="page-wrapper">
  <div class="container-fluid">
    <div class="row"><div class="col-lg-12"><h1 class="page-header"><?= APP_NAME ?></h1></div></div>

    <div class="row">
      <div class="col-lg-12">
<!-- Top Content -->


<session class="bpm">
  <div class="container">
    
<header class="toolbar">
  <h1>Contratos — Cadastro</h1>
  <div class="actions">
    <a class="btn" href="contratos-listar.html">Listar contratos</a>
  </div>
</header>

<form class="card" autocomplete="off" novalidate>
  <p class="subtitle">Identificação</p>
  <div class="grid cols-3">
    <div><label>Tipo *</label><select>
      <option>Compra</option><option>Garantia</option><option>Suporte</option>
      <option>Locação</option><option>Sub-locação</option><option>Outros</option></select></div>
    <div><label>Fornecedor *</label><input type="text" placeholder="Fabricante/Distribuidor"/></div>
    <div><label>Nº / Referência *</label><input type="text" placeholder="Identificador do contrato"/></div>
  </div>

  <div class="grid cols-4">
    <div><label>Vigência início *</label><input type="date"/></div>
    <div><label>Vigência fim *</label><input type="date"/></div>
    <div><label>SLA</label><input type="text" placeholder="Resposta/Atendimento/Conclusão"/></div>
    <div><label>Status *</label><select><option>Ativo</option><option>Expirado</option><option>Suspenso</option></select></div>
  </div>

  <div class="grid cols-3">
    <div><label>Valor mensal</label><input type="number" min="0" step="0.01"/></div>
    <div><label>Valor total</label><input type="number" min="0" step="0.01"/></div>
    <div><label>Centro de custo</label><input type="text"/></div>
  </div>

  <div class="divider"></div>
  <p class="subtitle">Abrangência</p>
  <div class="grid cols-3">
    <div><label>Empresa/Entidade</label><select><option>Matriz</option><option>Filial 01</option></select></div>
    <div><label>Locais/setores</label><input type="text" placeholder="Se aplicável"/></div>
    <div><label>Categorias/Modelos cobertos</label><input type="text" placeholder="Ex.: Notebooks; Impressoras"/></div>
  </div>

  <div class="divider"></div>
  <p class="subtitle">Documentos</p>
  <div class="grid cols-3">
    <div class="stack">
      <label>Contrato (PDF)</label>
      <div class="file-zone">Arraste aqui ou <button type="button" class="btn small">escolher</button><input type="file" accept="application/pdf"/></div>
    </div>
    <div class="stack">
      <label>Anexos</label>
      <div class="file-zone">Arraste aqui ou <button type="button" class="btn small">escolher</button><input type="file" multiple/></div>
    </div>
    <div class="stack">
      <label>Outros</label>
      <div class="file-zone">Arraste aqui ou <button type="button" class="btn small">escolher</button><input type="file" multiple/></div>
    </div>
  </div>

  <div class="divider"></div>
  <p class="subtitle">Observações</p>
  <textarea placeholder="Cláusulas importantes, multa, renovação automática etc."></textarea>

  <div class="divider"></div>
  <div style="display:flex;justify-content:flex-end;gap:10px">
    <button class="btn" type="button">Cancelar</button>
    <button class="btn primary" type="button">Salvar (visual)</button>
  </div>
</form>

<div class="card"><p class="hint">Mock visual. Depois mapeamos vínculos com ativos e alertas.</p></div>

</session>

  <!-- Fim Content -->
        </div>
    </div>
  </div>
</div>

<?php
include_once ROOT_PATH . 'system/includes/code_footer.php';
?>






<?php
include_once ROOT_PATH . 'system/includes/footer.php';
?>