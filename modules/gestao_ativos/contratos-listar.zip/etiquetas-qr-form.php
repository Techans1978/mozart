<?php
// modules/bpm/bpm_designer.php
// Mozart BPM — Modeler com Properties + Element Templates (CDN + fallback local)

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../config.php';
require_once ROOT_PATH . '/system/config/autenticacao.php';
require_once ROOT_PATH . '/system/config/connect.php';

// Abre <html><head>...<body>
include_once ROOT_PATH . 'system/includes/head.php';
?>

<link href="<?= BASE_URL ?>/modules/gestao_ativos/includes/css/style_gestao_ativos.css?v=1.0.0" rel="stylesheet">

<?php
// (se o seu navbar ficar dentro do head/footer, não precisa incluir aqui)
include_once ROOT_PATH . 'system/includes/navbar.php';
?>

<!-- Page Content -->
<div id="page-wrapper">
  <div class="container-fluid">
    <div class="row"><div class="col-lg-12"><h1 class="page-header"><?= APP_NAME ?></h1></div></div>

    <div class="row">
      <div class="col-lg-12">
<!-- Top Content -->


<session class="bpm">

  <div class="container">
    
<header class="toolbar">
  <h1>Etiquetas / QR — Emissão</h1>
  <div class="actions"><a class="btn" href="etiquetas-qr-listar.html">Listar</a></div>
</header>

<form class="card" onsubmit="return false;">
  <p class="subtitle">Seleção de itens</p>
  <div class="grid cols-3">
    <div><label>Por</label><select><option>Ativos</option><option>Modelo</option><option>Categoria</option><option>Lote (range)</option></select></div>
    <div><label>Filtro</label><input type="text" placeholder="Ex.: NB-0001, NB-0002 / Latitude 5440"/></div>
    <div><label>Quantidade</label><input type="number" min="1" value="1"/></div>
  </div>
  <div class="divider"></div>
  <p class="subtitle">Layout</p>
  <div class="grid cols-3">
    <div><label>Modelo</label><select><option>Padrão 62×29mm</option><option>Pequeno 30×20mm</option><option>Grande 100×50mm</option></select></div>
    <div><label>Campos</label><input type="text" placeholder="Tag, Serial, Modelo, QR"/></div>
    <div><label>Logo</label><select><option>Sem logo</option><option>Logo padrão</option></select></div>
  </div>
  <div class="row" style="justify-content:flex-end;gap:10px"><button class="btn">Pré-visualizar</button><button class="btn primary">Gerar PDF</button></div>
</form>

</session>

  <!-- Fim Content -->
        </div>
    </div>
  </div>
</div>

<?php
include_once ROOT_PATH . 'system/includes/code_footer.php';
?>






<?php
include_once ROOT_PATH . 'system/includes/footer.php';
?>