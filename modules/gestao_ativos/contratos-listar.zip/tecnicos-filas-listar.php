<!doctype html>
<html lang="pt-BR">
<head>
  <title>Técnicos & Filas — Listar</title>
  
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <link rel="stylesheet" href="includes/css/style_gestao_ativos.css?v=1.0.0">

</head>
<body class="bpm">
  <div class="container">
    
<header class="toolbar">
  <h1>Técnicos & Filas — Listar</h1>
  <div class="actions"><a class="btn" href="tecnicos-filas-form.html">Novo</a></div>
</header>

<form class="card" onsubmit="return false;">
  <p class="subtitle">Filtros</p>
  <div class="grid cols-4">
    <div><label>Tipo</label><select><option>—</option><option>Técnico</option><option>Fila</option></select></div>
    <div><label>Time</label><input type="text" placeholder="ex.: Oficina, Campo"/></div>
    <div><label>Skills</label><input type="text" placeholder="ex.: Impressoras, Rede"/></div>
    <div><label>Entidade</label><select><option>—</option><option>Matriz</option><option>Filial 01</option></select></div>
  </div>
</form>
<section id="list" class="grid cols-2">

<article class="card">
  <div class="row" style="justify-content:space-between;align-items:flex-start">
    <div>
      <div style="font-weight:700">Ana Silva</div>
      <div class="hint">Técnico • Time: Oficina</div>
    </div>
    <div class="row" style="gap:6px;flex-wrap:wrap"><span class="pill">Ativo</span> <span class="pill">online</span></div>
  </div>
  <div class="divider"></div>
  <div class="grid cols-3"><div><label>Skills</label><div>Impressoras, Zebra</div></div><div><label>Filas</label><div>Oficina, Nível 2</div></div><div><label>OS abertas</label><div>5</div></div></div>
  <div class="divider"></div>
  <div class="row" style="justify-content:flex-end;gap:8px"><a class="btn small" href="tecnicos-filas-form.html">Editar</a><a class="btn small" href="#">Inativar</a><a class="btn small" href="#">Excluir</a><a class="btn small" href="#">Ver agenda</a></div>
</article>

<article class="card">
  <div class="row" style="justify-content:space-between;align-items:flex-start">
    <div>
      <div style="font-weight:700">Fila — Nível 1</div>
      <div class="hint">Escopo: Global</div>
    </div>
    <div class="row" style="gap:6px;flex-wrap:wrap"><span class="pill">Ativa</span> <span class="pill">8x5</span></div>
  </div>
  <div class="divider"></div>
  <div class="grid cols-3"><div><label>Serviços</label><div>Notebook, Celular</div></div><div><label>SLAs</label><div>N1: 8x5</div></div><div><label>Técnicos</label><div>6</div></div></div>
  <div class="divider"></div>
  <div class="row" style="justify-content:flex-end;gap:8px"><a class="btn small" href="tecnicos-filas-form.html">Editar</a><a class="btn small" href="#">Inativar</a><a class="btn small" href="#">Excluir</a><a class="btn small" href="#">Transferir OS</a></div>
</article>

</section>

  </div>
  
</body>
</html>