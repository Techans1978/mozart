<?php
// modules/bpm/bpm_designer.php
// Mozart BPM — Modeler com Properties + Element Templates (CDN + fallback local)

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../config.php';
require_once ROOT_PATH . '/system/config/autenticacao.php';
require_once ROOT_PATH . '/system/config/connect.php';

// Abre <html><head>...<body>
include_once ROOT_PATH . 'system/includes/head.php';
?>

<link href="<?= BASE_URL ?>/modules/gestao_ativos/includes/css/style_gestao_ativos.css?v=1.0.0" rel="stylesheet">

<?php
// (se o seu navbar ficar dentro do head/footer, não precisa incluir aqui)
include_once ROOT_PATH . 'system/includes/navbar.php';
?>

<!-- Page Content -->
<div id="page-wrapper">
  <div class="container-fluid">
    <div class="row"><div class="col-lg-12"><h1 class="page-header"><?= APP_NAME ?></h1></div></div>

    <div class="row">
      <div class="col-lg-12">
<!-- Top Content -->


<session class="bpm">
  <div class="container">
    
<header class="toolbar">
  <h1>Licenças — Cadastro</h1>
  <div class="actions">
    <a class="btn" href="licencas-listar.html">Listar licenças</a>
  </div>
</header>

<form class="card" autocomplete="off" novalidate>
  <p class="subtitle">Identificação</p>
  <div class="grid cols-3">
    <div>
      <label>Tipo de licença *</label>
      <select id="tipo-lic">
        <option>Software</option>
        <option>Domínio (DNS)</option>
        <option>Clube/Associação</option>
        <option>SaaS/Serviço</option>
        <option>Outro</option>
      </select>
    </div>
    <div>
      <label>Fornecedor/Emissor *</label>
      <input type="text" placeholder="Ex.: Microsoft, Registro.br, Clube X"/>
    </div>
    <div>
      <label>Produto/Nome *</label>
      <input type="text" placeholder="Ex.: Microsoft 365 E3 / dominio.com.br / Plano Ouro"/>
    </div>
  </div>

  <div class="grid cols-3">
    <div>
      <label>Código/Chave/ID</label>
      <input type="text" placeholder="Chave de licença ou identificador"/>
    </div>
    <div>
      <label>Status *</label>
      <select>
        <option>Ativa</option><option>Pendente</option><option>Suspensa</option><option>Expirada</option>
      </select>
    </div>
    <div>
      <label>Entidade/Empresa *</label>
      <select><option>Matriz</option><option>Filial 01</option></select>
    </div>
  </div>

  <div class="grid cols-3">
    <div>
      <label>Quantidade / Vagas</label>
      <input type="number" min="0" placeholder="Assentos/usuários/copies"/>
    </div>
    <div>
      <label>Escopo</label>
      <select>
        <option>Usuários</option><option>Ativos</option><option>Organização</option>
      </select>
    </div>
    <div>
      <label>Centro de custo</label>
      <input type="text" placeholder="Opcional"/>
    </div>
  </div>

  <div class="divider"></div>
  <p class="subtitle">Ciclo e renovação</p>
  <div class="grid cols-4">
    <div>
      <label>Tipo de cobrança *</label>
      <select id="tipo-cob">
        <option value="recorrente">Recorrente</option>
        <option value="fixa">Fixa (período específico)</option>
      </select>
    </div>
    <div>
      <label>Periodicidade</label>
      <select id="periodicidade">
        <option>Mensal</option>
        <option>Trimestral</option>
        <option>Semestral</option>
        <option>Anual</option>
        <option>Bianual</option>
      </select>
      <span class="hint">Usado quando recorrente</span>
    </div>
    <div>
      <label>Início da vigência *</label>
      <input type="date" id="vig-inicio"/>
    </div>
    <div>
      <label>Fim da vigência *</label>
      <input type="date" id="vig-fim"/>
      <span class="hint">Calculado pela periodicidade ou informado</span>
    </div>
  </div>

  <div class="grid cols-3">
    <div>
      <label>Renovação automática</label>
      <select id="auto-renova"><option>Sim</option><option>Não</option></select>
    </div>
    <div>
      <label>Período de carência (dias)</label>
      <input type="number" min="0" placeholder="Ex.: 7"/>
    </div>
    <div>
      <label>Forma de pagamento</label>
      <select><option>Fatura</option><option>Cartão</option><option>PIX/Transferência</option><option>Débito automático</option></select>
    </div>
  </div>

  <div class="grid cols-3">
    <div>
      <label>Valor por ciclo</label>
      <input type="number" min="0" step="0.01" placeholder="0,00"/>
    </div>
    <div>
      <label>Moeda</label>
      <input type="text" value="BRL"/>
    </div>
    <div>
      <label>Nº da última fatura</label>
      <input type="text" placeholder="Referência para conciliação"/>
    </div>
  </div>

  <div class="divider"></div>
  <p class="subtitle">Alertas de renovação</p>
  <div id="alert-list" class="stack"></div>
  <div class="row">
    <button type="button" class="btn small" id="add-alert">+ Adicionar alerta</button>
    <span class="hint">Ex.: 30 dias antes para TI, 5 dias antes para Financeiro.</span>
  </div>

  <div class="divider"></div>
  <p class="subtitle">Cobertura / Alocações</p>
  <div id="alloc-list" class="stack"></div>
  <button type="button" class="btn small" id="add-alloc">+ Adicionar alocação</button>
  <span class="hint">Vincule usuários/ativos/entidades que consomem a licença.</span>

  <div class="divider"></div>
  <p class="subtitle">Domínio (quando tipo = Domínio)</p>
  <div class="grid cols-3">
    <div><label>Domínio</label><input type="text" placeholder="ex.: minhaempresa.com.br"/></div>
    <div><label>Registrante</label><input type="text" placeholder="Pessoa/Empresa"/></div>
    <div><label>DNS/Provedor</label><input type="text" placeholder="Cloudflare / Registro.br"/></div>
  </div>

  <div class="divider"></div>
  <p class="subtitle">Documentos</p>
  <div class="grid cols-3">
    <div class="stack">
      <label>Contrato/Termos (PDF)</label>
      <div class="file-zone">Arraste aqui ou <button type="button" class="btn small">escolha</button><input type="file" accept="application/pdf"/></div>
    </div>
    <div class="stack">
      <label>Notas/Faturas</label>
      <div class="file-zone">Arraste aqui ou <button type="button" class="btn small">escolha</button><input type="file" multiple/></div>
    </div>
    <div class="stack">
      <label>Outros anexos</label>
      <div class="file-zone">Arraste aqui ou <button type="button" class="btn small">escolha</button><input type="file" multiple/></div>
    </div>
  </div>

  <div class="divider"></div>
  <p class="subtitle">Observações</p>
  <textarea placeholder="Cláusulas, limites de uso, contatos de suporte, observações gerais."></textarea>

  <div class="divider"></div>
  <div style="display:flex;justify-content:flex-end;gap:10px">
    <button class="btn" type="button">Cancelar</button>
    <button class="btn primary" type="button">Salvar (visual)</button>
  </div>
</form>

<div class="card"><p class="hint">Mock visual. Depois mapeamos a engine de renovação (jobs/alertas) e a modelagem (licencas, ciclos, alertas, alocacoes).</p></div>

</session>

  <!-- Fim Content -->
        </div>
    </div>
  </div>
</div>

<?php
include_once ROOT_PATH . 'system/includes/code_footer.php';
?>

<script>
// ---------- Alertas ----------
function alertRow(){
  const el=document.createElement('div'); el.className='grid cols-4'; el.style.alignItems='end';
  el.innerHTML=`
    <div>
      <label>Antecedência</label>
      <input type="number" min="0" value="30"/>
      <span class="hint">Dias antes do vencimento</span>
    </div>
    <div>
      <label>Canal</label>
      <select><option>E-mail</option><option>WhatsApp</option><option>SMS</option><option>Sistema</option></select>
    </div>
    <div>
      <label>Destinatários</label>
      <input type="text" placeholder="ti@, financeiro@, usuário..."/>
    </div>
    <div class="row">
      <button type="button" class="btn small danger">Remover</button>
    </div>
    <div class="cols-span-4">
      <label>Mensagem (opcional)</label>
      <input type="text" placeholder="Texto do lembrete"/>
    </div>
  `;
  el.querySelector('.btn.danger').addEventListener('click', ()=>el.remove());
  return el;
}

// ---------- Alocações ----------
function allocRow(){
  const el=document.createElement('div'); el.className='grid cols-4'; el.style.alignItems='end';
  el.innerHTML=`
    <div>
      <label>Tipo</label>
      <select><option>Usuário</option><option>Ativo</option><option>Entidade/Empresa</option></select>
    </div>
    <div>
      <label>Referência</label>
      <input type="text" placeholder="ex.: usuario@empresa / TAG-001 / Matriz"/>
    </div>
    <div>
      <label>Desde</label>
      <input type="date"/>
    </div>
    <div class="row">
      <button type="button" class="btn small danger">Remover</button>
    </div>
    <div class="cols-span-4">
      <label>Observações</label>
      <input type="text" placeholder="Ex.: 1 de 5 assentos alocados"/>
    </div>
  `;
  el.querySelector('.btn.danger').addEventListener('click', ()=>el.remove());
  return el;
}

// Bind lists
const alertList=document.getElementById('alert-list');
const allocList=document.getElementById('alloc-list');
document.getElementById('add-alert').addEventListener('click', ()=>alertList.appendChild(alertRow()));
document.getElementById('add-alloc').addEventListener('click', ()=>allocList.appendChild(allocRow()));
// start with defaults
alertList.appendChild(alertRow());
allocList.appendChild(allocRow());

// ---------- Lógica simples de UI para recorrência ----------
const tipoCob=document.getElementById('tipo-cob');
const periodicidade=document.getElementById('periodicidade');
tipoCob.addEventListener('change', ()=>{
  const rec = tipoCob.value==='recorrente';
  periodicidade.disabled = !rec;
});
</script>

<?php
include_once ROOT_PATH . 'system/includes/footer.php';
?>