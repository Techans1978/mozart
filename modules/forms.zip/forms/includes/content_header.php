<!-- CSS locais (ajuste o caminho se sua pasta for diferente) -->
<link rel="stylesheet" href="./vendor/form-js@1.17.0/dist/assets/form-js.css" />
<link rel="stylesheet" href="./vendor/form-js@1.17.0/dist/assets/form-js-editor.css" />