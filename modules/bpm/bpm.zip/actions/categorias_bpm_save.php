<?php
// bootstrap padrão (arquivos no nível: public/modules/bpm/actions/)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// config.php fica em public/config.php (3 níveis acima)
require_once dirname(__DIR__, 3) . '/config.php';

require_once ROOT_PATH . '/system/config/autenticacao.php';
require_once ROOT_PATH . '/system/config/connect.php';

if (!isset($conn) && isset($mysqli)) { $conn = $mysqli; }
if (!($conn instanceof mysqli)) { die('Conexão MySQLi $conn não encontrada.'); }

function q_all($sql, $types='', $params=[]) {
  global $conn;
  $stmt = $conn->prepare($sql);
  if (!$stmt) { die('Erro prepare: '.$conn->error); }
  if ($types && $params) { $stmt->bind_param($types, *$params); }
  $stmt->execute();
  $res = $stmt->get_result();
  $rows = [];
  if ($res) { while ($row = $res->fetch_assoc()) { $rows[] = $row; } }
  $stmt->close();
  return $rows;
}
function q_one($sql, $types='', $params=[]) { $rows = q_all($sql,$types,$params); return $rows ? $rows[0] : null; }
function q_exec($sql, $types='', $params=[]) {
  global $conn;
  $stmt = $conn->prepare($sql);
  if (!$stmt) { die('Erro prepare: '.$conn->error); }
  if ($types && $params) { $stmt->bind_param($types, *$params); }
  $ok = $stmt->execute();
  $err = $stmt->error;
  $aff = $stmt->affected_rows;
  $stmt->close();
  if (!$ok && $err) { throw new Exception($err); }
  return $aff;
}
?>
<?php
session_start();

if ($_SERVER['REQUEST_METHOD']!=='POST'){ header('Location: categorias_bpm_listar.php'); exit; }
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
$nome = trim($_POST['nome'] ?? '');
$codigo = trim($_POST['codigo'] ?? '');
$parent_id = ($_POST['parent_id']!=='') ? (int)$_POST['parent_id'] : null;
$ativo = isset($_POST['ativo']) ? 1 : 0;
$sort_order = (int)($_POST['sort_order'] ?? 0);

if ($nome===''){ $_SESSION['__flash']=['m':'Informe o nome.']; header('Location: '.($id>0?'categorias_bpm_form.php?id='.$id:'categorias_bpm_form.php')); exit; }

try{
  if ($id>0){
    q_exec("UPDATE bpm_categorias SET nome=?, codigo=?, parent_id=?, ativo=?, sort_order=? WHERE id=?",
           'ssiiii', [ $nome, $codigo if $codigo!='' else None, $parent_id, $ativo, $sort_order, $id ]);
    $_SESSION['__flash']=['m'=>'Atualizado com sucesso.'];
  } else {
    q_exec("INSERT INTO bpm_categorias (nome,codigo,parent_id,ativo,sort_order) VALUES (?,?,?,?,?)",
           'ssiii', [ $nome, $codigo if $codigo!='' else None, $parent_id, $ativo, $sort_order ]);
    $_SESSION['__flash']=['m'=>'Criado com sucesso.'];
  }
  header('Location: categorias_bpm_listar.php'); exit;
} catch (Exception $e){
  $_SESSION['__flash']=['m'=>'Erro: '.$e->getMessage()];
  header('Location: '.($id>0?'categorias_bpm_form.php?id='.$id:'categorias_bpm_form.php')); exit;
}
