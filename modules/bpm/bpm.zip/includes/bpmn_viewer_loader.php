<?php
// Include para carregar bpmn-js via CDN com fallback local (se quiser add no vendor futuramente)
?>
<script src="https://unpkg.com/bpmn-js@11.5.0/dist/bpmn-viewer.development.js"></script>