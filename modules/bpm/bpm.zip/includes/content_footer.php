<!-- modules/bpm/includes/content_footer.php -->
 <!-- Camunda Modeler JS (CDN) -->
<script id="camunda-js-cdn" src="https://unpkg.com/camunda-bpmn-js@5/dist/camunda-platform-modeler.development.js"></script>
