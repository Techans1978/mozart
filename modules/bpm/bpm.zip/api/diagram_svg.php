<?php
header('Content-Type: image/svg+xml; charset=utf-8');
echo '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="200"><rect x="0" y="0" width="640" height="200" fill="#f3f4f6"/><text x="20" y="110" font-family="Arial" font-size="18">Viewer do diagrama (stub). Trocar por bpmn-js com highlight via XML.</text></svg>';
