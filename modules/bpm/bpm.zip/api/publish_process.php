<?php
header('Content-Type: application/json; charset=utf-8');
require_once dirname(__DIR__, 2) . '/config/connect.php'; // $conn

// helper
function mozart_storage(): string {
  $dir = __DIR__ . '/../storage/processes';
  if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
  return $dir;
}

$in = json_decode(file_get_contents('php://input'), true);
$name = isset($in['name']) ? preg_replace('/[^a-zA-Z0-9_\-]/','_', $in['name']) : '';
$version = isset($in['version']) ? max(1, (int)$in['version']) : 1;

if (!$name) { http_response_code(400); echo json_encode(['error'=>'name required']); exit; }

/** 1) banco **/
try {
  if ($conn->query("SHOW TABLES LIKE 'bpm_processes'")->num_rows == 0) {
    $conn->query("CREATE TABLE IF NOT EXISTS bpm_processes (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(191) NOT NULL,
      version INT NOT NULL,
      status ENUM('draft','published','archived') DEFAULT 'draft',
      bpmn_xml MEDIUMTEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uniq_name_version (name, version)
    )");
  }
  $stmt = $conn->prepare("UPDATE bpm_processes SET status='published' WHERE name=? AND version=?");
  if ($stmt) {
    $stmt->bind_param("si", $name, $version);
    $stmt->execute();
    $affected = $stmt->affected_rows;
    $stmt->close();
    if ($affected > 0) {
      // espelha no manifest.json
      $dir = mozart_storage();
      $manifest = $dir . '/manifest.json';
      $data = is_file($manifest) ? json_decode(file_get_contents($manifest), true) : ['items'=>[]];
      $found = false;
      foreach ($data['items'] as &$it) {
        if ($it['name'] === $name && (int)$it['version'] === $version) { $it['status']='published'; $found=true; break; }
      }
      if (!$found) $data['items'][] = ['name'=>$name,'version'=>$version,'status'=>'published'];
      file_put_contents($manifest, json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));

      echo json_encode(['ok'=>true, 'name'=>$name, 'version'=>$version, 'status'=>'published']); exit;
    }
  }
} catch (Throwable $e) {
  // fallback
}

/** 2) fallback manifest **/
$dir = mozart_storage();
$manifest = $dir . '/manifest.json';
$data = is_file($manifest) ? json_decode(file_get_contents($manifest), true) : ['items'=>[]];
$found = false;
foreach ($data['items'] as &$it) {
  if ($it['name'] === $name && (int)$it['version'] === $version) { $it['status']='published'; $found=true; break; }
}
if (!$found) $data['items'][] = ['name'=>$name,'version'=>$version,'status'=>'published'];
file_put_contents($manifest, json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));

echo json_encode(['ok'=>true, 'name'=>$name, 'version'=>$version, 'status'=>'published']);

?>