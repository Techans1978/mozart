<?php
/**
 * Listar Fluxos de BPM + filtros
 * /modules/bpm/bpm_list.php
 */

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../config.php';
require_once ROOT_PATH . '/system/config/autenticacao.php';
require_once ROOT_PATH . '/system/config/connect.php';

/* =========================================================
   MAPA DE TABELAS / CAMPOS (ajuste se necessário)
   ---------------------------------------------------------
   Tabela principal.....: bpm_processes
     id (PK, int)
     name (varchar)
     version (int)
     status (enum: draft,published,archived)
     category_id (int, FK -> bpm_categories.id)
     updated_at (datetime)
     updated_by (int, opcional)

   Tabelas auxiliares...: bpm_categories(id,name)
                          bpm_profiles(id,name)
                          bpm_groups(id,name)
                          bpm_roles(id,name)

   Relações (N:N).......: bpm_process_profiles(process_id, profile_id)
                          bpm_process_groups(process_id, group_id)
                          bpm_process_roles(process_id, role_id)
   ========================================================= */

//
// helpers
//
function h($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function param($key, $default='') { return isset($_GET[$key]) ? trim((string)$_GET[$key]) : $default; }

// filtros
$q       = param('q');
$cat     = param('cat');       // category_id
$perfil  = param('perfil');    // profile_id
$grupo   = param('grupo');     // group_id
$papel   = param('papel');     // role_id

// paginação
$page    = max(1, (int)param('page', 1));
$perPage = max(10, min(100, (int)param('pp', 20)));
$offset  = ($page - 1) * $perPage;

// carrega opções de selects (categorias, perfis, grupos, papeis)
function loadOptions(mysqli $conn, $table) {
  $out = [];
  if ($rs = $conn->query("SELECT id, name FROM {$table} ORDER BY name")) {
    while ($row = $rs->fetch_assoc()) $out[] = $row;
    $rs->close();
  }
  return $out;
}
$optCategories = loadOptions($conn, "bpm_categories");
$optProfiles   = loadOptions($conn, "bpm_profiles");
$optGroups     = loadOptions($conn, "bpm_groups");
$optRoles      = loadOptions($conn, "bpm_roles");

//
// monta SQL com filtros
//
$w = [];
$p = [];
$t = ""; // tipos dos params para bind

if ($q !== '') {
  $w[] = "(p.name LIKE CONCAT('%', ?, '%'))";
  $p[] = $q;
  $t  .= "s";
}
if ($cat !== '') {
  $w[] = "p.category_id = ?";
  $p[] = (int)$cat;
  $t  .= "i";
}
if ($perfil !== '') {
  $w[] = "EXISTS (SELECT 1 FROM bpm_process_profiles bp WHERE bp.process_id = p.id AND bp.profile_id = ?)";
  $p[] = (int)$perfil;
  $t  .= "i";
}
if ($grupo !== '') {
  $w[] = "EXISTS (SELECT 1 FROM bpm_process_groups bg WHERE bg.process_id = p.id AND bg.group_id = ?)";
  $p[] = (int)$grupo;
  $t  .= "i";
}
if ($papel !== '') {
  $w[] = "EXISTS (SELECT 1 FROM bpm_process_roles br WHERE br.process_id = p.id AND br.role_id = ?)";
  $p[] = (int)$papel;
  $t  .= "i";
}

$where = $w ? ("WHERE " . implode(" AND ", $w)) : "";

// total
$sqlCount = "SELECT COUNT(*) AS n
             FROM bpm_processes p
             {$where}";
$stmt = $conn->prepare($sqlCount);
if ($t) $stmt->bind_param($t, ...$p);
$stmt->execute();
$total = 0;
$stmt->bind_result($total);
$stmt->fetch();
$stmt->close();

// dados
$sql = "SELECT p.id, p.name, p.version, p.status, p.updated_at,
               c.name AS category
        FROM bpm_processes p
        LEFT JOIN bpm_categories c ON c.id = p.category_id
        {$where}
        ORDER BY p.updated_at DESC, p.id DESC
        LIMIT ? OFFSET ?";

$t2  = $t . "ii";
$p2  = $p;
$p2[] = $perPage;
$p2[] = $offset;

$stmt = $conn->prepare($sql);
$stmt->bind_param($t2, ...$p2);
$stmt->execute();
$rs = $stmt->get_result();
$rows = [];
while ($row = $rs->fetch_assoc()) $rows[] = $row;
$stmt->close();

// paginação
$pages = max(1, (int)ceil($total / $perPage));

// HEAD/HTML gerais
include_once ROOT_PATH . '/system/includes/head.php';
include_once ROOT_PATH . '/system/includes/navbar.php';

?>
<style>
  #page-wrapper { background:#f6f7f9; }
  .card { background:#fff; border:1px solid #e5e7eb; border-radius:12px; }
  .filters .form-control { border-radius:10px; }
  .btn-rounded { border-radius:10px; }
  .badge { border-radius:8px; padding:.25rem .5rem; font-weight:600; }
  .badge.draft { background:#eef2ff; color:#3730a3; }
  .badge.published { background:#ecfdf5; color:#065f46; }
  .badge.archived { background:#fef3c7; color:#92400e; }
  .table > :not(caption) > * > * { vertical-align:middle; }
</style>

<div id="page-wrapper">
  <div class="container-fluid">
    <div class="row"><div class="col-lg-12"><h1 class="page-header">Fluxos de BPM</h1></div></div>

    <!-- Filtros -->
    <div class="row">
      <div class="col-lg-12">
        <div class="card p-3 filters mb-3">
          <form method="get" class="row g-2 align-items-end">
            <div class="col-md-4">
              <label class="form-label">Nome</label>
              <input type="text" name="q" value="<?= h($q) ?>" class="form-control" placeholder="Pesquisar por nome do fluxo...">
            </div>
            <div class="col-md-2">
              <label class="form-label">Categoria</label>
              <select name="cat" class="form-control">
                <option value="">Todas</option>
                <?php foreach ($optCategories as $o): ?>
                  <option value="<?= $o['id'] ?>" <?= ($cat===(string)$o['id']?'selected':'') ?>><?= h($o['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-2">
              <label class="form-label">Perfis</label>
              <select name="perfil" class="form-control">
                <option value="">Todos</option>
                <?php foreach ($optProfiles as $o): ?>
                  <option value="<?= $o['id'] ?>" <?= ($perfil===(string)$o['id']?'selected':'') ?>><?= h($o['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-2">
              <label class="form-label">Grupos</label>
              <select name="grupo" class="form-control">
                <option value="">Todos</option>
                <?php foreach ($optGroups as $o): ?>
                  <option value="<?= $o['id'] ?>" <?= ($grupo===(string)$o['id']?'selected':'') ?>><?= h($o['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>
            <div class="col-md-2">
              <label class="form-label">Papéis</label>
              <select name="papel" class="form-control">
                <option value="">Todos</option>
                <?php foreach ($optRoles as $o): ?>
                  <option value="<?= $o['id'] ?>" <?= ($papel===(string)$o['id']?'selected':'') ?>><?= h($o['name']) ?></option>
                <?php endforeach; ?>
              </select>
            </div>

            <div class="col-12 d-flex gap-2 mt-2">
              <button class="btn btn-dark btn-rounded" type="submit">Filtrar</button>
              <a class="btn btn-outline-secondary btn-rounded" href="<?= BASE_URL ?>/modules/bpm/bpm_list.php">Limpar</a>

              <div class="ms-auto"></div>

              <!-- Botão Wizard -->
              <a class="btn btn-primary btn-rounded" href="<?= BASE_URL ?>/modules/bpm/wizard_bpm.php">
                + Novo (Wizard BPM)
              </a>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Resultado -->
    <div class="row">
      <div class="col-lg-12">
        <div class="card p-3">
          <div class="d-flex align-items-center mb-2">
            <div class="fw-bold">Encontrados: <?= (int)$total ?></div>
            <div class="ms-auto">
              <form method="get" class="d-inline">
                <!-- preserva filtros na mudança de page size -->
                <input type="hidden" name="q" value="<?= h($q) ?>">
                <input type="hidden" name="cat" value="<?= h($cat) ?>">
                <input type="hidden" name="perfil" value="<?= h($perfil) ?>">
                <input type="hidden" name="grupo" value="<?= h($grupo) ?>">
                <input type="hidden" name="papel" value="<?= h($papel) ?>">
                <select name="pp" class="form-select d-inline w-auto" onchange="this.form.submit()">
                  <?php foreach ([10,20,50,100] as $pp): ?>
                    <option value="<?= $pp ?>" <?= $perPage==$pp?'selected':'' ?>><?= $pp ?>/pág</option>
                  <?php endforeach; ?>
                </select>
              </form>
            </div>
          </div>

          <div class="table-responsive">
            <table class="table table-hover align-middle">
              <thead>
                <tr>
                  <th>Fluxo</th>
                  <th>Versão</th>
                  <th>Categoria</th>
                  <th>Status</th>
                  <th>Atualizado</th>
                  <th class="text-end">Ações</th>
                </tr>
              </thead>
              <tbody>
              <?php if (!$rows): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">Nenhum fluxo encontrado.</td></tr>
              <?php else: ?>
                <?php foreach ($rows as $r): ?>
                  <tr>
                    <td class="fw-semibold"><?= h($r['name']) ?></td>
                    <td>v<?= (int)$r['version'] ?></td>
                    <td><?= h($r['category'] ?? '—') ?></td>
                    <td>
                      <?php
                        $st = $r['status'] ?? 'draft';
                        $cls = $st==='published'?'published':($st==='archived'?'archived':'draft');
                      ?>
                      <span class="badge <?= $cls ?>"><?= h($st) ?></span>
                    </td>
                    <td><?= h($r['updated_at']) ?></td>
                    <td class="text-end">
                      <div class="btn-group">
                        <!-- Abrir no Designer -->
                        <a class="btn btn-sm btn-outline-secondary"
                           href="<?= BASE_URL ?>/modules/bpm/bpm_designer.php?id=<?= (int)$r['id'] ?>">
                           Designer
                        </a>

                        <!-- Publicar -->
                        <a class="btn btn-sm btn-outline-success"
                           href="<?= BASE_URL ?>/modules/bpm/api/publish_process.php?id=<?= (int)$r['id'] ?>"
                           onclick="return confirm('Publicar este fluxo?');">
                           Publicar
                        </a>

                        <!-- Duplicar -->
                        <a class="btn btn-sm btn-outline-primary"
                           href="<?= BASE_URL ?>/modules/bpm/api/duplicate_process.php?id=<?= (int)$r['id'] ?>"
                           onclick="return confirm('Duplicar este fluxo?');">
                           Duplicar
                        </a>

                        <!-- Excluir -->
                        <a class="btn btn-sm btn-outline-danger"
                           href="<?= BASE_URL ?>/modules/bpm/api/delete_process.php?id=<?= (int)$r['id'] ?>"
                           onclick="return confirm('Excluir este fluxo? Esta ação é irreversível.');">
                           Excluir
                        </a>
                      </div>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php endif; ?>
              </tbody>
            </table>
          </div>

          <!-- paginação -->
          <?php if ($pages > 1): ?>
            <nav>
              <ul class="pagination mb-0">
                <?php
                  // helper link mantendo filtros
                  function pageLink($n) {
                    $params = $_GET;
                    $params['page'] = $n;
                    return '?' . http_build_query($params);
                  }
                ?>
                <li class="page-item <?= $page<=1?'disabled':'' ?>">
                  <a class="page-link" href="<?= $page>1 ? pageLink($page-1) : '#' ?>">«</a>
                </li>
                <?php
                  $window = 3;
                  $start = max(1, $page-$window);
                  $end   = min($pages, $page+$window);
                  for ($i=$start; $i<=$end; $i++):
                ?>
                  <li class="page-item <?= $i==$page?'active':'' ?>">
                    <a class="page-link" href="<?= pageLink($i) ?>"><?= $i ?></a>
                  </li>
                <?php endfor; ?>
                <li class="page-item <?= $page>=$pages?'disabled':'' ?>">
                  <a class="page-link" href="<?= $page<$pages ? pageLink($page+1) : '#' ?>">»</a>
                </li>
              </ul>
            </nav>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
include_once ROOT_PATH . '/system/includes/footer.php';
