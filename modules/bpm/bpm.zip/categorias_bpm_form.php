<?php
// modules/bpm/bpm_designer.php
// Mozart BPM — Modeler com Properties + Element Templates (CDN + fallback local)

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../../config.php';
require_once ROOT_PATH . '/system/config/autenticacao.php';
require_once ROOT_PATH . '/system/config/connect.php';

if (!isset($conn) && isset($mysqli)) { $conn = $mysqli; }
if (!($conn instanceof mysqli)) { die('Conexão MySQLi $conn não encontrada.'); }

function q_all($sql, $types='', $params=[]) {
  global $conn;
  $stmt = $conn->prepare($sql);
  if (!$stmt) { die('Erro prepare: '.$conn->error); }
  if ($types && $params) {
    // bind_param precisa de referências
    $refs = [];
    foreach ($params as $k => $v) { $refs[$k] = &$params[$k]; }
    $stmt->bind_param($types, ...$refs);
  }
  $stmt->execute();
  $res = $stmt->get_result();
  $rows = [];
  if ($res) { while ($row = $res->fetch_assoc()) { $rows[] = $row; } }
  $stmt->close();
  return $rows;
}

function q_one($sql, $types='', $params=[]) {
  $rows = q_all($sql, $types, $params);
  return $rows ? $rows[0] : null;
}

function q_exec($sql, $types='', $params=[]) {
  global $conn;
  $stmt = $conn->prepare($sql);
  if (!$stmt) { die('Erro prepare: '.$conn->error); }
  if ($types && $params) {
    $refs = [];
    foreach ($params as $k => $v) { $refs[$k] = &$params[$k]; }
    $stmt->bind_param($types, ...$refs);
  }
  $ok = $stmt->execute();
  $err = $stmt->error;
  $aff = $stmt->affected_rows;
  $stmt->close();
  if (!$ok && $err) { throw new Exception($err); }
  return $aff;
}

?>
<?php
session_start();

$flash = $_SESSION['__flash'] ?? null; unset($_SESSION['__flash']);

$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$ativos = isset($_GET['ativos']) ? (int)$_GET['ativos'] : -1;

$sql = "SELECT c.id, c.nome, c.codigo, c.ativo, c.sort_order, c.parent_id,
               GROUP_CONCAT(a.nome ORDER BY p.depth SEPARATOR ' / ') AS full_path,
               MAX(p.depth) AS depth
        FROM bpm_categorias c
        JOIN bpm_categorias_paths p ON p.descendant_id=c.id
        JOIN bpm_categorias a ON a.id=p.ancestor_id
        WHERE 1=1";
$types=''; $params=[];
if ($q!==''){ $sql .= " AND (c.nome LIKE ? OR c.codigo LIKE ?)"; $types.='ss'; $like = "%".$q."%";$params[] = $like; $params[] = $like; }
if ($ativos===0 || $ativos===1){ $sql .= " AND c.ativo=?"; $types.='i'; $params[]=$ativos; }
$sql .= " GROUP BY c.id, c.nome, c.codigo, c.ativo, c.sort_order, c.parent_id
          ORDER BY full_path, c.sort_order, c.id";

$rows = q_all($sql,$types,$params);
?>
<?php
session_start();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$cat = ['id'=>0,'nome'=>'','codigo'=>'','parent_id'=>null,'ativo'=>1,'sort_order'=>0];

if ($id>0) {
  $row = q_one("SELECT * FROM bpm_categorias WHERE id=?", 'i', [$id]);
  if (!$row) { $_SESSION['__flash']=['m'=>'Categoria não encontrada.']; header('Location: categorias_bpm_listar.php'); exit; }
  $cat = $row;
}

$types=''; $params=[];
$sqlParents = "SELECT c.id, GROUP_CONCAT(a.nome ORDER BY p.depth SEPARATOR ' / ') AS path
               FROM bpm_categorias c
               JOIN bpm_categorias_paths p ON p.descendant_id=c.id
               JOIN bpm_categorias a ON a.id=p.ancestor_id
               WHERE 1=1";
if ($id>0){ $sqlParents .= " AND c.id NOT IN (SELECT descendant_id FROM bpm_categorias_paths WHERE ancestor_id=?)"; $types.='i'; $params[]=$id; }
$sqlParents .= " GROUP BY c.id ORDER BY path";
$parentOptions = q_all($sqlParents,$types,$params);

// Abre <html><head>...<body>
include_once ROOT_PATH . 'system/includes/head.php';

// Inclui dependencias BPM
include_once ROOT_PATH . 'modules/bpm/includes/content_header.php';

// Inclui dependencias BPM
include_once ROOT_PATH . 'modules/bpm/includes/content_style.php';

// (se o seu navbar ficar dentro do head/footer, não precisa incluir aqui)
include_once ROOT_PATH . 'system/includes/navbar.php';
?>

<!-- Page Content -->
<div id="page-wrapper">
  <div class="container-fluid">
    <div class="row"><div class="col-lg-12"><h1 class="page-header"><?= APP_NAME ?></h1></div></div>

    <div class="row">
      <div class="col-lg-12">
<!-- Top Content -->

<h3><?= $id>0?'Editar':'Nova'?> Categoria</h3>
<form method="post" action="<?= BASE_URL ?>/modules/bpm/actions/categorias_bpm_save.php">
  <input type="hidden" name="id" value="<?= (int)$id ?>">
  <div><label>Nome *</label><br><input type="text" name="nome" value="<?= htmlspecialchars($cat['nome']) ?>" required></div>
  <div><label>Código</label><br><input type="text" name="codigo" maxlength="40" value="<?= htmlspecialchars($cat['codigo'] ?? '') ?>"></div>
  <div><label>Categoria Pai</label><br>
    <select name="parent_id">
      <option value="">— (raiz) —</option>
      <?php foreach($parentOptions as $op): ?>
        <option value="<?= (int)$op['id'] ?>" <?= ((string)$cat['parent_id']===(string)$op['id']?'selected':'') ?>>
          <?= htmlspecialchars($op['path']) ?>
        </option>
      <?php endforeach; ?>
    </select>
  </div>
  <div><label>Ordem</label><br><input type="number" name="sort_order" value="<?= (int)$cat['sort_order'] ?>"></div>
  <div><label><input type="checkbox" name="ativo" <?= ((int)$cat['ativo']===1?'checked':'') ?>> Ativa</label></div>
  <div style="margin-top:8px;">
    <a href="categorias_bpm_listar.php">Voltar</a>
    <button type="submit">Salvar</button>
  </div>
</form>
<?php
// carrega seus scripts globais + Camunda JS (inserido no code_footer.php)
include_once ROOT_PATH . 'system/includes/code_footer.php';
?>

<?php
// Inclui dependencias BPM
include_once ROOT_PATH . 'modules/bpm/includes/content_footer.php';
?>

<?php
// fecha </body></html>
include_once ROOT_PATH . 'system/includes/footer.php';
